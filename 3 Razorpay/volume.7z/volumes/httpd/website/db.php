<?php
$servername = "db";
$username = "admin";
$password = "mananx22";
$db = "apache";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

?>